// Prepara la cartella www/: copia l'app, mette le librerie (pdf.js, jsPDF) dentro l'app così funziona anche senza internet.
import fs from 'node:fs'; import path from 'node:path';
const out = 'www', src = 'www-src';
fs.rmSync(out, { recursive: true, force: true });
fs.cpSync(src, out, { recursive: true });
fs.mkdirSync(path.join(out, 'vendor'), { recursive: true });
fs.copyFileSync('node_modules/pdfjs-dist/build/pdf.min.js', out + '/vendor/pdf.min.js');
fs.copyFileSync('node_modules/pdfjs-dist/build/pdf.worker.min.js', out + '/vendor/pdf.worker.min.js');
fs.copyFileSync('node_modules/jspdf/dist/jspdf.umd.min.js', out + '/vendor/jspdf.umd.min.js');
let h = fs.readFileSync(out + '/index.html', 'utf8');
h = h.replace('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js', 'vendor/pdf.min.js')
     .replace('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js', 'vendor/pdf.worker.min.js')
     .replace('https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', 'vendor/jspdf.umd.min.js');
if (h.includes('cdnjs.cloudflare.com')) throw new Error('rimasto un link CDN in index.html');
fs.writeFileSync(out + '/index.html', h);
let a = fs.readFileSync(out + '/app.js', 'utf8');
a = a.split('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js').join('vendor/pdf.worker.min.js');
if (a.includes('cdnjs.cloudflare.com')) throw new Error('rimasto un link CDN in app.js');
fs.writeFileSync(out + '/app.js', a);
console.log('www pronto');
