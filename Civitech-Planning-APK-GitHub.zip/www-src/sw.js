/* Service worker: l'app si apre anche senza rete e si aggiorna da sola.
   File dell'app e librerie: prima la rete (così gli aggiornamenti arrivano a tutti i colleghi), se manca la rete usa la copia salvata.
   /api non viene mai messo da parte. Per forzare l'aggiornamento della copia, cambiare VERSION. */
var VERSION = 'civitech-v20';
var SHELL = ['./', 'index.html', 'styles.css', 'app.js', 'platform.js', 'config.js', 'manifest.webmanifest', 'icons/icon-192.png'];
self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(VERSION).then(function (c) { return c.addAll(SHELL); }).then(function () { return self.skipWaiting(); }));
});
self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (ks) { return Promise.all(ks.filter(function (k) { return k !== VERSION; }).map(function (k) { return caches.delete(k); })); }).then(function () { return self.clients.claim(); }));
});
self.addEventListener('fetch', function (e) {
  var r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.pathname.indexOf('/api/') === 0) return;
  e.respondWith(fetch(r).then(function (res) {
    if (res && (res.ok || res.type === 'opaque')) { var cp = res.clone(); caches.open(VERSION).then(function (c) { c.put(r, cp); }); }
    return res;
  }).catch(function () { return caches.match(r).then(function (m) { return m || caches.match('index.html'); }); }));
});
