/* 'locale': ogni telefono tiene i propri dati, nessun server, nessun accesso.
   'server': dati sul server dei colleghi (vedi server.js). */
window.CIVITECH_MODE = 'locale';
