/* Sostituisce i servizi della piattaforma Claude (utente, database, dettatura, download)
   con servizi propri. app.js non cambia: chiama window.claude.use(nome) come prima. */
(function () {
  'use strict';
  if (window.claude) return;
  var TK = 'civitech-token', UK = 'civitech-uid';
  var ls = {
    get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} },
    del: function (k) { try { localStorage.removeItem(k); } catch (e) {} }
  };

  /* ---- accesso ---- */
  var loginP = null;
  function loginUI(msg) {
    if (loginP) return loginP;
    loginP = new Promise(function (resolve) {
      var o = document.createElement('div');
      o.id = 'login';
      o.style.cssText = 'position:fixed;inset:0;z-index:99;background:#fff;display:flex;align-items:center;justify-content:center;padding:24px;font-family:Inter,system-ui,sans-serif';
      o.innerHTML = '<form style="width:100%;max-width:320px;display:flex;flex-direction:column;gap:12px">' +
        '<div style="font:700 30px/1 \'Barlow Condensed\',sans-serif;letter-spacing:.06em;text-transform:uppercase">Civitech <span style="color:#d9820f">Planning</span></div>' +
        '<div id="lmsg" style="color:#b3261e;font-size:14px;min-height:18px"></div>' +
        '<input name="n" placeholder="Nome utente" autocomplete="username" autocapitalize="none" style="font-size:17px;padding:12px;border:1px solid #d3d9df;border-radius:8px">' +
        '<input name="p" type="password" placeholder="PIN o password" autocomplete="current-password" style="font-size:17px;padding:12px;border:1px solid #d3d9df;border-radius:8px">' +
        '<button style="font-size:17px;font-weight:600;padding:12px;border:0;border-radius:8px;background:#d9820f;color:#fff">Entra</button></form>';
      document.body.appendChild(o);
      o.querySelector('#lmsg').textContent = msg || '';
      o.querySelector('form').addEventListener('submit', function (ev) {
        ev.preventDefault();
        var f = ev.target, n = f.n.value.trim(), p = f.p.value;
        fetch('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: n, pin: p }) })
          .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
          .then(function (x) {
            if (!x.ok) { o.querySelector('#lmsg').textContent = x.j.error || 'Accesso non riuscito'; return; }
            ls.set(TK, x.j.token); ls.set(UK, x.j.user);
            o.remove(); loginP = null; resolve(x.j.user);
          })
          .catch(function () { o.querySelector('#lmsg').textContent = 'Server non raggiungibile. Riprova.'; });
      });
    });
    return loginP;
  }
  function ensureUser() {
    if (ls.get(TK) && ls.get(UK)) return Promise.resolve(ls.get(UK));
    return new Promise(function (res) {
      if (document.body) loginUI().then(res); else document.addEventListener('DOMContentLoaded', function () { loginUI().then(res); });
    });
  }
  var user = { id: function () { return ensureUser(); } };

  /* ---- database: stessa forma usata dall'app (doc / collection / get / set) ---- */
  function api(method, path, body) {
    return fetch('/api/' + path, {
      method: method,
      headers: { Authorization: 'Bearer ' + ls.get(TK), 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body)
    }).then(function (r) {
      if (r.status === 401) { ls.del(TK); throw { code: 'unauthorized', message: 'accesso scaduto' }; }
      if (r.status === 404) return null;
      if (!r.ok) throw { code: 'http_' + r.status, message: 'errore ' + r.status };
      return r.json();
    });
  }
  function docRef(col, id) {
    return {
      get: function () { return api('GET', 'c/' + col + '/' + id).then(function (d) { return { exists: !!d, id: id, data: function () { return d; } }; }); },
      set: function (obj) { return api('PUT', 'c/' + col + '/' + id, obj); }
    };
  }
  function colRef(col) {
    return {
      get: function () { return api('GET', 'c/' + col).then(function (l) { return { docs: (l || []).map(function (x) { return { id: x.id, data: function () { return x.data; } }; }) }; }); },
      doc: function (id) { return docRef(col, id); }
    };
  }
  var db = { doc: function () { return { collection: colRef }; } };

  /* ---- dettatura (Web Speech del browser) ---- */
  var SR = window.SpeechRecognition || window.webkitSpeechRecognition, dict = null;
  if (SR) {
    var rec = null, onS = function () {}, onF = function () {}, onP = function () {};
    dict = {
      start: function () {
        return new Promise(function (res, rej) {
          rec = new SR(); rec.lang = 'it-IT'; rec.continuous = true; rec.interimResults = true;
          rec.onstart = function () { onS({ state: 'listening' }); res(); };
          rec.onend = function () { onS({ state: 'idle', reason: 'stopped' }); };
          rec.onerror = function (e) { if (e.error === 'not-allowed') { rej({ code: 'not_granted' }); } onS({ state: 'idle', reason: e.error }); };
          rec.onresult = function (e) {
            for (var i = e.resultIndex; i < e.results.length; i++) {
              var t = e.results[i][0].transcript;
              if (e.results[i].isFinal) onF({ text: t }); else onP({ text: t });
            }
          };
          try { rec.start(); } catch (x) { rej(x); }
        });
      },
      stop: function () { try { rec && rec.stop(); } catch (e) {} return Promise.resolve(); },
      onState: function (f) { onS = f; }, onFinal: function (f) { onF = f; }, onPartial: function (f) { onP = f; }
    };
  }

  /* ---- scaricamento file (PDF del planning) ---- */
  var downloads = {
    save: function (o) {
      var C = window.Capacitor, P = C && C.Plugins;
      if (C && C.isNativePlatform && C.isNativePlatform() && P && P.Filesystem && P.Share) {
        var u8 = new Uint8Array(o.data), bin = '';
        for (var i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
        return P.Filesystem.writeFile({ path: o.filename, data: btoa(bin), directory: 'CACHE' })
          .then(function (r) { return P.Share.share({ title: o.filename, files: [r.uri], dialogTitle: 'Stampa o invia il planning' }); });
      }
      var blob = new Blob([o.data], { type: /\.pdf$/i.test(o.filename) ? 'application/pdf' : 'application/octet-stream' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = o.filename;
      document.body.appendChild(a); a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
      return Promise.resolve();
    }
  };

  var SERVER = window.CIVITECH_MODE === 'server';   /* vedi config.js: 'locale' = ognuno per conto suo, nessun server */
  var caps = { user: SERVER ? user : null, db: SERVER ? db : null, dictation: dict, downloads: downloads, sample: null };
  window.claude = { use: function (n) { return Promise.resolve(caps[n] || null); } };
})();
