# Come ottenere il file APK di Civitech Planning (si invia su WhatsApp e si installa)

Non serve installare nulla sul tuo computer: l'APK lo costruisce GitHub gratis. Ci vogliono circa 15 minuti la prima volta. Serve un computer (non il telefono) e un indirizzo email.

## Costruire l'APK (una volta, e poi a ogni aggiornamento)
1. Vai su **github.com**, crea un account gratuito e accedi.
2. In alto a destra **+ → New repository**. Nome: `civitech-planning`. Scegli **Private**. Premi **Create repository**.
3. Estrai questo ZIP sul computer. Nella pagina del repository premi **uploading an existing file** e trascina **tutto il contenuto della cartella `apk`** (file e cartelle: `www-src`, `package.json`, `prepare.mjs`, `capacitor.config.json`, `.gitignore`). Premi **Commit changes**.
4. La cartella nascosta `.github` spesso non si trascina. Allora: **Add file → Create new file**, nel nome scrivi esattamente `.github/workflows/build-apk.yml`, incolla dentro il testo del file `build-apk.yml` che trovi in questo ZIP, poi **Commit changes**.
5. Apri la scheda **Actions**. Parte da sola la costruzione "Crea APK" (3-6 minuti). Se non parte: **Crea APK → Run workflow**.
6. Quando diventa verde, aprila e in fondo, sotto **Artifacts**, scarica **Civitech-Planning-APK** (è uno zip con dentro `app-debug.apk`).
7. Estrai lo zip: il file `app-debug.apk` lo mandi ai colleghi su WhatsApp.

## Installare sul telefono (colleghi compresi)
1. Su WhatsApp tocca il file, poi **Scarica** e **Apri** (o dalla cartella Download).
2. Android chiede di consentire l'installazione da questa fonte: tocca **Impostazioni → Consenti** e torna indietro.
3. Tocca **Installa**. L'icona "Civitech Planning" compare tra le app: la puoi trascinare in Home.
(Play Protect può avvisare che l'app non è nello store: scegli **Installa comunque**.)

## Aggiornare tutti
Quando ti preparo una nuova versione, sostituisci i file in `www-src` nel repository (Add file → Upload files), aspetta che Actions finisca, scarica il nuovo APK e rimandalo su WhatsApp. I colleghi lo installano **sopra** quello vecchio: i loro dati restano. La chiave di firma NON è nel pacchetto. Per poter aggiornare l'app sopra le versioni già installate, crea la chiave una sola volta e conservala:
`keytool -genkeypair -keystore civitech.keystore -storepass android -keypass android -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Civitech,O=Civitech,C=IT"`
poi `base64 -w0 civitech.keystore` e incolla il risultato in GitHub → Settings → Secrets and variables → Actions → New repository secret, nome `KEYSTORE_B64`. Senza questo segreto ogni costruzione genera una chiave diversa e i colleghi dovrebbero disinstallare l'app prima di installare quella nuova (perdendo i dati).

## Dati e privacy
Ogni telefono tiene i propri dati, nessun server. Il repository non contiene dati dei clienti.

## Note
- Il PDF di stampa si apre con il menu di condivisione di Android: da lì scegli la stampante o WhatsApp.
- La dettatura vocale potrebbe non essere disponibile nell'app Android: si può usare il microfono della tastiera.
- Gli allarmi suonano solo con l'app aperta.
- Questa procedura non è stata provata qui (mancano gli strumenti Android): se GitHub mostra un errore rosso in Actions, mandalo a chi mantiene l'app, di solito si risolve con una riga.
